/*
 * Author: Derek Martinez
 * Course: CSI 3471
 * Assignment: Lab 5
 * File: Make.java
 * Description: Your brief description
 */

package edu.baylor.cs.csi3471;

import java.util.*;
import java.util.stream.Collectors;

public class Make{
	private Set<ModelSettings> modelSettingSet;
	private String makeName;
	private static int id = 0;

	public Set<ModelSettings> getModelSettingSet() {
		return modelSettingSet;
	}
	public String getMakeName() {
		return makeName;
	}
	public void setMakeName(String makeName) {
		this.makeName = makeName;
	}
	public static int getId() {
		return id;
	}
	public static void setId(int id) {
		Make.id = id;
	}

	public Make(String[] line) {
		super();
		modelSettingSet = new HashSet<>();
		makeName = line[6];
		modelSettingSet.add(new ModelSettings(line));
		id++;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Make make)) return false;
		return Objects.equals(getModelSettingSet(), make.getModelSettingSet()) &&
				Objects.equals(getMakeName(), make.getMakeName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getModelSettingSet(), getMakeName());
	}

	@Override
	public String toString() {
		return "Make{" +
				", makeName='" + makeName + '\'' +
				"modelSettingSet=" + '\n' + modelSettingSet.stream()
				.sorted(Comparator.comparing(ModelSettings::getModelYear)
						.thenComparing(ModelSettings::getTransmission)
						.thenComparing(ModelSettings::getEngDisplacement))
				.toList() + '}' + '\n';
	}

	public Collection<Make> creatorPattern(String[] line, Collection<Make> makes) {
		Make existingMakes = null;
		for(Make make : makes){
			if(make.getMakeName().equalsIgnoreCase(line[6])) {
				existingMakes = make;
				break;
			}
		}

		if(existingMakes == null) {
			makes.add(new Make(line));
		} else {
			if(existingMakes.getModelSettingSet().stream()
					.noneMatch(model -> model.getModelName()
							.equalsIgnoreCase(line[7]))){
				existingMakes.getModelSettingSet().add(new ModelSettings(line));
			}
		}
 		return makes;
    }
}
