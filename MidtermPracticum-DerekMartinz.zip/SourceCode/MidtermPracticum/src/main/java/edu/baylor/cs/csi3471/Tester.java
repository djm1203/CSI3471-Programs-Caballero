/*
 * Author: Derek Martinez
 * Course: CSI 3471
 * Assignment: Lab 5
 * File: Tester.java
 * Description: Your brief description
 */

package edu.baylor.cs.csi3471;

import java.awt.*;
import java.awt.desktop.SystemSleepEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class Tester {
	private static final String[] columnTitles = new String[]{"city08","comb08","cylinders","displ","fuelType","highway08","make","model","trany","VClass","year\n"};
	private static final int FILE_NAME = 1;
	private static final int OPTION = 0;

	//reading file and option to print
	private static int readOption(String[] args) {
		Integer option = null;
		if (args.length < 2) {
			System.err.println("USAGE: java Tester <filename>");
			System.exit(1);
		} else {
			try {
				option = Integer.parseInt(args[OPTION]);
			} catch (NumberFormatException e) {
				System.err.println("call as java Tester <filename>");
				System.exit(1);
			}
		}
		return option;
	}

	//reading CSV and loading info
	private static Set<Make> loadCSV(String file) throws FileNotFoundException {
		BufferedReader reader = null;
		try {
			// ok, this is much faster than scanner :)
			reader = new BufferedReader(new FileReader(new File(file)));

			Set<Make> makes = new HashSet<>();
			String line = null;

			reader.readLine();
			reader.readLine();
			while ((line = reader.readLine()) != null) {
				String[] split = line.split(",");

				//skipping rows with null columns
				boolean skip = false;
				for(String column : split){
					if(column.isEmpty()){
						skip = true;
						break;
					}
				}
				if(!skip) {
					Make newMake = new Make(split);
					newMake.creatorPattern(split, makes);
				}
			}

			return makes;
		} catch (IOException e) {
			String hint = "";
			try {
				hint = "Current dir is: " + new File(".").getCanonicalPath();
			} catch (Exception local) {
				hint = local.getLocalizedMessage();
			}
			throw new FileNotFoundException(e.getLocalizedMessage() + "\n" + hint);

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					System.err.println(e.getLocalizedMessage());
				}
			}
		}
	}

	//main that reads file and tests info
	public static void main(String[] args) {
		int option = readOption(args);

		Set<Make> makes = null;
		try {
			makes = loadCSV(args[FILE_NAME]);

			switch (option) {
				case 1:
					printOptionOne(makes);
					break;
				case 2:
					String columnName = args[2];
					int value = Integer.parseInt(args[3]);
					//printOptionTwo(makes, columnName, value);
					break;
				case 3:
					printOptionThree(makes);
					break;
				case 4:
					printOptionFour(makes);
					break;
				default:
					System.out.println("ERROR: Enter a valid print option...");
					System.exit(1);
					break;
			}
		} catch (FileNotFoundException e) {
			System.err.println(e.getLocalizedMessage());
			System.exit(1);
		}
	}

	public static void printOptionOne(Collection<Make> makes) {
		System.out.println("Total Makes: " + makes.size());

		System.out.println("===============");
		List<Make> sortedMakes = makes.stream().sorted(Comparator.comparing(Make::getMakeName, String.CASE_INSENSITIVE_ORDER).reversed()).toList();
		for(Make make : sortedMakes) {
			System.out.println(make.getMakeName() + ": " + make.getModelSettingSet().size());
		}
		System.out.println("===============");
		for(Make make : sortedMakes) {
			System.out.println(make.toString());
			System.out.println("--------------");
		}
	}

	public static void printOptionTwo(Collection<Make> makes, String columnName, int val) {
		System.out.println("Sorted by: " + columnName + " & " + val);
		if(columnName.equalsIgnoreCase(columnTitles[2])){
			makes.stream().flatMap(make -> make.getModelSettingSet().stream())
					.sorted(Comparator.comparing(ModelSettings::getEngCylinders))
					.toList().forEach(System.out::println);
		} else if(columnName.equals(columnTitles[3])){
			makes.stream().flatMap(make -> make.getModelSettingSet().stream())
					.sorted(Comparator.comparing(ModelSettings::getEngDisplacement))
					.toList().forEach(System.out::println);
		} else if(columnName.equals(columnTitles[4])){
			makes.stream().flatMap(make -> make.getModelSettingSet().stream())
					.sorted(Comparator.comparing(ModelSettings::getFuelType))
					.toList().forEach(System.out::println);
		} else if(columnName.equals(columnTitles[6])){
			makes.stream().sorted(Comparator.comparing(Make::getMakeName))
					.toList().forEach(System.out::println);
		}
	}

	public static void printOptionThree(Collection<Make> makes) {
		System.out.println("Printing Option Three...");

		//Map<String, List<ModelSettings>> vClassAvg = makes.stream().flatMap(make -> make.getModelSettingSet().stream()).collect(Collectors.groupingBy(ModelSettings::getVehicleClass), ModelSettings.MPG::getAvgMPG);
		//Sorted Vehicle Classes
		makes.stream().flatMap(make -> make.getModelSettingSet().stream())
				.sorted(Comparator.comparing(ModelSettings::getVehicleClass))
				.toList().forEach(System.out::println);

	}

	public static void printOptionFour(Collection<Make> makes) {
		makes.stream().flatMap(make -> make.getModelSettingSet().stream())
				.sorted(Comparator.comparing(ModelSettings::getModelYear))
				.toList().forEach(System.out::println);
		Map<String, Long> makeCount = makes.stream().collect(Collectors.groupingBy(Make::getMakeName, Collectors.counting()));
		makeCount.forEach((item, num) -> System.out.println(item + " " + num));
	}
}
