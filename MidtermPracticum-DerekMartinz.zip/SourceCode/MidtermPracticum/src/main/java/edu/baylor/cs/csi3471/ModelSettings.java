/*
 * Author: Derek Martinez
 * Course: CSI 3471
 * Assignment: Lab 5
 * File: ModelSettings.java
 * Description: Your brief description
 */

package edu.baylor.cs.csi3471;

import java.util.Objects;

public class ModelSettings {

	//------------- MPG Class
	public static class MPG {
		private int cityMPG;
		private int hwyMPG;
		private int avgMPG;

		public int getCityMPG() {
			return cityMPG;
		}

		public void setCityMPG(int cityMPG) {
			this.cityMPG = cityMPG;
		}

		public int getHwyMPG() {
			return hwyMPG;
		}

		public void setHwyMPG(int hwyMPG) {
			this.hwyMPG = hwyMPG;
		}

		public int getAvgMPG() {
			return avgMPG;
		}

		public void setAvgMPG(int avgMPG) {
			this.avgMPG = avgMPG;
		}

		public MPG(String[] line) {
			cityMPG = (line[0].isEmpty()) ? 0 : Integer.parseInt(line[0]);
			avgMPG = (line[1].isEmpty()) ? 0 : Integer.parseInt(line[1]);
			hwyMPG = (line[5].isEmpty()) ? 0 : Integer.parseInt(line[5]);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (!(o instanceof MPG mpg)) return false;
            return getCityMPG() == mpg.getCityMPG() && getHwyMPG() == mpg.getHwyMPG() && getAvgMPG() == mpg.getAvgMPG();
		}

		@Override
		public int hashCode() {
			return Objects.hash(getCityMPG(), getHwyMPG(), getAvgMPG());
		}

		@Override
		public String toString() {
			return "MPG{" +
					"cityMPG=" + cityMPG +
					", avgMPG=" + avgMPG +
					", hwyMPG=" + hwyMPG +
					'}';
		}
	}

	//-------------- ModelSettings Class
	private MPG mpg;
	private int engCylinders;
	private double engDisplacement;
	private String fuelType;
	private String modelName;
	private String transmission;
	private String vehicleClass;
	private int modelYear;
	private static int id = 0;

	public MPG getMpg() {
		return mpg;
	}

	public void setMpg(MPG mpg) {
		this.mpg = mpg;
	}

	public int getEngCylinders() {
		return engCylinders;
	}
	public void setEngCylinders(int engCylinders) {
		this.engCylinders = engCylinders;
	}
	public double getEngDisplacement() {
		return engDisplacement;
	}
	public void setEngDisplacement(double engDisplacement) {
		this.engDisplacement = engDisplacement;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

	public String getVehicleClass() {
		return vehicleClass;
	}

	public void setVehicleClass(String vehicleClass) {
		this.vehicleClass = vehicleClass;
	}

	public int getModelYear() {
		return modelYear;
	}
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}
	public static int getId() {
		return id;
	}
	public static void setId(int id) {
		String uniqueID = String.format("%04d", id);
		ModelSettings.id = Integer.parseInt(uniqueID);
	}

	public ModelSettings(String[] line) {
		super();
		mpg = new MPG(line);
		engCylinders = line[2].isEmpty() ? 0 : Integer.parseInt(line[2]);
		engDisplacement = line[3].isEmpty() ? 0 : Double.parseDouble(line[3]);
		fuelType = line[4];
		modelName = line[7];
		transmission = line[8];
		vehicleClass = line[9];
		modelYear = line[10].isEmpty() ? 0 : Integer.parseInt(line[10]);
		setId(id);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof ModelSettings that)) return false;
		return getEngCylinders() == that.getEngCylinders() &&
				Double.compare(getEngDisplacement(), that.getEngDisplacement()) == 0 &&
				getModelYear() == that.getModelYear() &&
				Objects.equals(getFuelType(), that.getFuelType()) &&
				Objects.equals(getModelName(), that.getModelName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getEngCylinders(), getEngDisplacement(), getFuelType(), getModelName(), getModelYear());
	}

	@Override
	public String toString() {
		return "ModelSettings{" +
				"mpg=" + mpg +
				", engCylinders=" + engCylinders +
				", engDisplacement=" + engDisplacement +
				", fuelType='" + fuelType + '\'' +
				", modelName='" + modelName + '\'' +
				", transmission='" + transmission + '\'' +
				", vehicleClass='" + vehicleClass + '\'' +
				", modelYear=" + modelYear +
				'}' + '\n';
	}
}
